# Local LLM (Android / Snapdragon)

llama.cpp(JNI) + Jetpack Compose。Hugging FaceからGGUFを検索・DLして端末内で実行するアプリ。

## APKの作り方
### A) GitHub Actions(PC不要)
1. このフォルダをGitHubリポジトリにpush(mainブランチ)
2. Actionsタブ → Build APK → Artifacts の `local-llm-apk` をDL → 解凍してインストール

### B) 手元
Android Studio(Ladybug以降推奨)で開く → SDK/NDK/CMake 3.22.1を入れる → Build > Build APK。
CLIなら `gradle assembleRelease`(Gradle 8.10+)。出力: app/build/outputs/apk/release/

## 使い方
1. 「探す」: 検索 → モデルを選ぶ → 量子化ごとのファイルから DL(🟢=端末RAMに余裕)
2. 「モデル」: 読込 → 「チャット」へ
3. 「設定」: HFトークン、ctx/スレッド、OpenAI互換サーバー(既定は127.0.0.1のみ)

## 目安
- RAM 8GBなら 3B〜4BのQ4、12GB以上なら 7B〜8BのQ4が現実的
- スレッドは4前後(高性能コア数)が速いことが多い
- 8 Gen1以降なら

## 既知の制限
- CPU推論のみ(GPU/NPU未対応)、arm64-v8aのみ
- 分割GGUF(-00001-of-0000N)とマルチモーダル(mmproj)は非対応
- llama.cppは b5001 に固定(CMakeLists.txtのGIT_TAG)。更新時はJNIのAPI追従が必要
