#include <jni.h>
#include <atomic>
#include <string>
#include <vector>
#include "llama.h"

static std::atomic<bool> g_stop{false};

struct Handle {
    llama_model *model;
    int n_ctx;
    int n_threads;
};

// UTF-8として完結している先頭部分の長さ(途中で切れたマルチバイトは次回に回す)
static size_t utf8_valid_prefix(const std::string &s) {
    size_t n = s.size();
    for (size_t back = 1; back <= 4 && back <= n; back++) {
        unsigned char c = (unsigned char) s[n - back];
        if ((c & 0xC0) == 0x80) continue;
        size_t need = (c >= 0xF0) ? 4 : (c >= 0xE0) ? 3 : (c >= 0xC0) ? 2 : 1;
        return back < need ? n - back : n;
    }
    return n;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_example_localllm_LlamaBridge_load(JNIEnv *env, jobject, jstring path, jint nCtx, jint nThreads) {
    static bool inited = false;
    if (!inited) { llama_backend_init(); inited = true; }
    const char *p = env->GetStringUTFChars(path, nullptr);
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    mp.use_mmap = true;
    llama_model *m = nullptr;
    try { m = llama_model_load_from_file(p, mp); } catch (...) { m = nullptr; }
    env->ReleaseStringUTFChars(path, p);
    if (!m) return 0;
    return (jlong) new Handle{m, nCtx, nThreads};
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_localllm_LlamaBridge_free(JNIEnv *, jobject, jlong h) {
    if (!h) return;
    auto *hd = (Handle *) h;
    llama_model_free(hd->model);
    delete hd;
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_localllm_LlamaBridge_stop(JNIEnv *, jobject) { g_stop = true; }

extern "C" JNIEXPORT void JNICALL
Java_com_example_localllm_LlamaBridge_generate(JNIEnv *env, jobject, jlong h, jobjectArray roles,
                                               jobjectArray contents, jint maxTokens, jfloat temp,
                                               jobject cb) {
    g_stop = false;
    auto *hd = (Handle *) h;
    if (!hd) return;
    llama_model *model = hd->model;
    const llama_vocab *vocab = llama_model_get_vocab(model);

    jclass cbc = env->GetObjectClass(cb);
    jmethodID mid = env->GetMethodID(cbc, "onToken", "([B)Z");
    auto emit = [&](const std::string &s) -> bool {
        jbyteArray arr = env->NewByteArray((jsize) s.size());
        env->SetByteArrayRegion(arr, 0, (jsize) s.size(), (const jbyte *) s.data());
        jboolean cont = env->CallBooleanMethod(cb, mid, arr);
        env->DeleteLocalRef(arr);
        if (env->ExceptionCheck()) { env->ExceptionClear(); return false; }
        return cont;
    };

    try {
        // --- チャットテンプレート適用 ---
        jsize n_msg = env->GetArrayLength(roles);
        std::vector<std::string> role_s(n_msg), content_s(n_msg);
        for (jsize i = 0; i < n_msg; i++) {
            auto jr = (jstring) env->GetObjectArrayElement(roles, i);
            const char *r = env->GetStringUTFChars(jr, nullptr);
            role_s[i] = r;
            env->ReleaseStringUTFChars(jr, r);
            env->DeleteLocalRef(jr);
            auto jc = (jbyteArray) env->GetObjectArrayElement(contents, i);
            jsize len = env->GetArrayLength(jc);
            content_s[i].resize(len);
            env->GetByteArrayRegion(jc, 0, len, (jbyte *) &content_s[i][0]);
            env->DeleteLocalRef(jc);
        }
        std::vector<llama_chat_message> msgs(n_msg);
        size_t total = 0;
        for (jsize i = 0; i < n_msg; i++) {
            msgs[i] = {role_s[i].c_str(), content_s[i].c_str()};
            total += content_s[i].size() + role_s[i].size();
        }
        const char *tmpl = llama_model_chat_template(model, nullptr);
        std::vector<char> buf(total * 2 + 1024);
        int len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int) buf.size());
        if (len < 0) {  // テンプレート非対応 → ChatMLにフォールバック
            tmpl = "chatml";
            len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int) buf.size());
        }
        if (len > (int) buf.size()) {
            buf.resize(len + 1);
            len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int) buf.size());
        }
        if (len < 0) { emit("[チャットテンプレートの適用に失敗しました]"); return; }
        std::string prompt(buf.data(), len);

        // --- トークナイズ ---
        int n_tok = -llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(), nullptr, 0, true, true);
        if (n_tok <= 0) { emit("[トークナイズに失敗しました]"); return; }
        std::vector<llama_token> toks(n_tok);
        llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(), toks.data(), (int) toks.size(), true, true);
        if (n_tok + 8 >= hd->n_ctx) {
            emit("[プロンプトがコンテキスト長を超えています。設定でコンテキスト長を増やすか、会話をクリアしてください]");
            return;
        }

        // --- コンテキスト作成(生成のたびに作り直してKVキャッシュをクリア) ---
        llama_context_params cp = llama_context_default_params();
        cp.n_ctx = hd->n_ctx;
        cp.n_batch = 512;
        cp.n_threads = hd->n_threads;
        cp.n_threads_batch = hd->n_threads;
        llama_context *ctx = llama_init_from_model(model, cp);
        if (!ctx) { emit("[コンテキストを作れませんでした(メモリ不足の可能性)]"); return; }

        llama_sampler *smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
        if (temp <= 0.01f) {
            llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
        } else {
            llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
            llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
            llama_sampler_chain_add(smpl, llama_sampler_init_temp(temp));
            llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
        }

        bool ok = true;
        for (int i = 0; i < n_tok && ok; i += cp.n_batch) {
            int cnt = std::min((int) cp.n_batch, n_tok - i);
            if (g_stop) { ok = false; break; }
            if (llama_decode(ctx, llama_batch_get_one(toks.data() + i, cnt)) != 0) {
                emit("[デコードに失敗しました]");
                ok = false;
            }
        }

        std::string pending;
        int generated = 0;
        int pos = n_tok;
        while (ok && generated < maxTokens && pos < hd->n_ctx - 1 && !g_stop) {
            llama_token t = llama_sampler_sample(smpl, ctx, -1);
            if (llama_vocab_is_eog(vocab, t)) break;
            char piece[256];
            int pn = llama_token_to_piece(vocab, t, piece, sizeof(piece), 0, true);
            if (pn > 0) pending.append(piece, pn);
            size_t v = utf8_valid_prefix(pending);
            if (v > 0) {
                bool cont = emit(pending.substr(0, v));
                pending.erase(0, v);
                if (!cont) break;
            }
            if (llama_decode(ctx, llama_batch_get_one(&t, 1)) != 0) break;
            generated++;
            pos++;
        }
        llama_sampler_free(smpl);
        llama_free(ctx);
    } catch (...) {
        emit("[ネイティブ側で例外が発生しました]");
    }
}
