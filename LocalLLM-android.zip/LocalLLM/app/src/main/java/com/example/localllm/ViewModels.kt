package com.example.localllm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class ChatViewModel : ViewModel() {
    val messages = MutableStateFlow<List<ChatMsg>>(emptyList())
    val generating = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)

    fun send(text: String) {
        if (generating.value || text.isBlank()) return
        val s = Core.settings
        val history = buildList {
            if (s.systemPrompt.isNotBlank()) add(ChatMsg("system", s.systemPrompt))
            addAll(messages.value)
            add(ChatMsg("user", text))
        }
        messages.value = messages.value + ChatMsg("user", text) + ChatMsg("assistant", "")
        generating.value = true
        error.value = null
        viewModelScope.launch {
            try {
                Engine.chat(history, s.maxTokens, s.temperature) { piece ->
                    messages.update { l -> l.dropLast(1) + l.last().copy(text = l.last().text + piece) }
                    true
                }
            } catch (e: Exception) {
                error.value = e.message
            } finally {
                generating.value = false
            }
        }
    }

    fun stop() = Engine.stop()
    fun clear() { if (!generating.value) messages.value = emptyList() }
    override fun onCleared() { Engine.stop() }
}

class SearchViewModel : ViewModel() {
    val query = MutableStateFlow("")
    val results = MutableStateFlow<List<HfModel>>(emptyList())
    val loading = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
    val selected = MutableStateFlow<HfModel?>(null)
    val files = MutableStateFlow<List<HfSibling>>(emptyList())
    val filesLoading = MutableStateFlow(false)

    init { search("") }

    fun search(q: String = query.value) {
        query.value = q
        viewModelScope.launch {
            loading.value = true
            error.value = null
            try { results.value = Core.hf.search(q) } catch (e: Exception) { error.value = e.message }
            loading.value = false
        }
    }

    fun open(m: HfModel?) {
        selected.value = m
        files.value = emptyList()
        if (m == null) return
        viewModelScope.launch {
            filesLoading.value = true
            error.value = null
            try { files.value = Core.hf.files(m.id) } catch (e: Exception) { error.value = e.message }
            filesLoading.value = false
        }
    }
}
