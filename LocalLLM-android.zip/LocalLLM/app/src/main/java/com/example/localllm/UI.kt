package com.example.localllm

import android.app.ActivityManager
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import java.io.File

fun fmtSize(b: Long): String = when {
    b <= 0 -> "?"
    b >= (1L shl 30) -> "%.2f GB".format(b / 1073741824.0)
    else -> "%.0f MB".format(b / 1048576.0)
}

@Composable
fun AppRoot() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val tabs = listOf("💬" to "チャット", "🔎" to "探す", "📦" to "モデル", "⚙️" to "設定")
    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEachIndexed { i, (ic, label) ->
                NavigationBarItem(
                    selected = tab == i, onClick = { tab = i },
                    icon = { Text(ic) }, label = { Text(label) }
                )
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> ChatScreen()
                1 -> SearchScreen()
                2 -> LibraryScreen(onLoaded = { tab = 0 })
                else -> SettingsScreen()
            }
        }
    }
}

// ---------------- チャット ----------------
@Composable
fun ChatScreen(vm: ChatViewModel = viewModel()) {
    val msgs by vm.messages.collectAsState()
    val gen by vm.generating.collectAsState()
    val err by vm.error.collectAsState()
    val loaded by Engine.loaded.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(msgs.size, msgs.lastOrNull()?.text?.length) {
        if (msgs.isNotEmpty()) listState.scrollToItem(msgs.lastIndex)
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                loaded?.let { "🟢 $it" } ?: "⚪ モデル未読込(「モデル」タブで読み込み)",
                style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f), maxLines = 1
            )
            TextButton(onClick = { vm.clear() }, enabled = !gen) { Text("クリア") }
        }
        HorizontalDivider()
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = listState) {
            items(msgs.size) { i ->
                val m = msgs[i]
                val user = m.role == "user"
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = if (user) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        color = if (user) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.widthIn(max = 320.dp)
                    ) {
                        Text(
                            m.text.ifEmpty { "…" },
                            Modifier.padding(10.dp),
                        )
                    }
                }
            }
        }
        err?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp)) }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(
                input, { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("メッセージ") }, maxLines = 4
            )
            Spacer(Modifier.width(8.dp))
            if (gen) {
                Button(onClick = { vm.stop() }) { Text("停止") }
            } else {
                Button(onClick = { vm.send(input); input = "" }, enabled = loaded != null && input.isNotBlank()) {
                    Text("送信")
                }
            }
        }
    }
}

// ---------------- HF検索 ----------------
@Composable
fun SearchScreen(vm: SearchViewModel = viewModel()) {
    val selected by vm.selected.collectAsState()
    if (selected != null) {
        BackHandler { vm.open(null) }
        ModelDetail(vm, selected!!)
        return
    }
    val q by vm.query.collectAsState()
    val results by vm.results.collectAsState()
    val loading by vm.loading.collectAsState()
    val err by vm.error.collectAsState()
    var text by remember { mutableStateOf(q) }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                text, { text = it }, modifier = Modifier.weight(1f), singleLine = true,
                placeholder = { Text("Hugging Faceでモデル検索 (GGUF)") }
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.search(text) }) { Text("検索") }
        }
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            listOf("qwen", "gemma", "llama", "phi", "smollm", "日本語").forEach {
                TextButton(onClick = { text = it; vm.search(it) }) { Text(it) }
            }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        LazyColumn {
            items(results, key = { it.id }) { m ->
                Card(onClick = { vm.open(m) }, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(m.id, style = MaterialTheme.typography.titleSmall)
                        val gated = m.gated != null && m.gated.toString() != "false"
                        Text(
                            "⬇ ${m.downloads}  ♥ ${m.likes}" + if (gated) "  🔒gated" else "",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ModelDetail(vm: SearchViewModel, m: HfModel) {
    val ctx = LocalContext.current
    val files by vm.files.collectAsState()
    val loading by vm.filesLoading.collectAsState()
    val err by vm.error.collectAsState()
    val dl by Core.downloads.active.collectAsState()
    val ver by Core.store.version.collectAsState()
    val totalMem = remember {
        ActivityManager.MemoryInfo().also {
            (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(it)
        }.totalMem
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.open(null) }) { Text("← 戻る") }
            Text(m.id, style = MaterialTheme.typography.titleSmall)
        }
        Text("端末RAM: ${fmtSize(totalMem)}(🟢快適 / 🟡ギリギリ / 🔴重い は目安)", style = MaterialTheme.typography.bodySmall)
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        LazyColumn {
            items(files, key = { it.rfilename }) { f ->
                val key = "${m.id}/${f.rfilename}"
                val st = dl[key]
                val size = f.size ?: 0L
                val done = remember(ver, key) { Core.store.fileFor(m.id, f.rfilename).exists() }
                val ratio = if (totalMem > 0) size.toDouble() / totalMem else 0.0
                val fit = when { ratio < 0.45 -> "🟢"; ratio < 0.65 -> "🟡"; else -> "🔴" }
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(f.rfilename, style = MaterialTheme.typography.bodyMedium)
                        Text("$fit ${fmtSize(size)}", style = MaterialTheme.typography.bodySmall)
                        if (st != null && st.error == null) {
                            LinearProgressIndicator(
                                progress = { if (st.total > 0) (st.done.toFloat() / st.total).coerceIn(0f, 1f) else 0f },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text("${fmtSize(st.done)} / ${fmtSize(st.total)}", style = MaterialTheme.typography.bodySmall)
                        }
                        if (st?.error != null) Text(st.error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                    when {
                        done -> Text("✔ 済")
                        st != null && st.error == null -> TextButton(onClick = { Core.downloads.cancel(key) }) { Text("中止") }
                        else -> Button(onClick = { Core.downloads.start(m.id, f.rfilename, size) }) {
                            Text(if (st?.error != null) "再試行" else "DL")
                        }
                    }
                }
                HorizontalDivider()
            }
        }
    }
}

// ---------------- ダウンロード済みモデル ----------------
@Composable
fun LibraryScreen(onLoaded: () -> Unit) {
    val scope = rememberCoroutineScope()
    val ver by Core.store.version.collectAsState()
    val loaded by Engine.loaded.collectAsState()
    val dl by Core.downloads.active.collectAsState()
    var loadingName by remember { mutableStateOf<String?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    val files: List<File> = remember(ver) { Core.store.list() }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("ダウンロード済みモデル", style = MaterialTheme.typography.titleMedium)
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (dl.isNotEmpty()) {
            Text("ダウンロード中", style = MaterialTheme.typography.labelMedium)
            dl.values.forEach { st ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(st.file, maxLines = 1)
                        if (st.error == null) LinearProgressIndicator(
                            progress = { if (st.total > 0) (st.done.toFloat() / st.total).coerceIn(0f, 1f) else 0f },
                            modifier = Modifier.fillMaxWidth()
                        ) else Text(st.error, color = MaterialTheme.colorScheme.error)
                    }
                    TextButton(onClick = { Core.downloads.cancel(st.key) }) { Text("中止") }
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
        }
        if (files.isEmpty()) Text("まだモデルがありません。「探す」タブからダウンロードしてください。")
        LazyColumn {
            items(files, key = { it.name }) { f ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(f.name, style = MaterialTheme.typography.bodyMedium)
                        Text(fmtSize(f.length()), style = MaterialTheme.typography.bodySmall)
                    }
                    when {
                        loadingName == f.name -> CircularProgressIndicator(Modifier.size(24.dp))
                        loaded == f.name -> Text("🟢読込済")
                        else -> Button(onClick = {
                            scope.launch {
                                loadingName = f.name; err = null
                                try { Engine.load(f); onLoaded() } catch (e: Exception) { err = e.message }
                                loadingName = null
                            }
                        }, enabled = loadingName == null) { Text("読込") }
                    }
                    TextButton(onClick = {
                        scope.launch { if (loaded == f.name) Engine.unload(); Core.store.delete(f) }
                    }) { Text("削除") }
                }
                HorizontalDivider()
            }
        }
    }
}

// ---------------- 設定 ----------------
@Composable
private fun NumField(label: String, value: String, keyboard: KeyboardType = KeyboardType.Number, onValid: (String) -> Unit) {
    var t by remember { mutableStateOf(value) }
    OutlinedTextField(
        t, { t = it; onValid(it) }, label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard), modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun SettingsScreen() {
    val s = Core.settings
    val running by Core.server.running.collectAsState()
    var serverErr by remember { mutableStateOf<String?>(null) }
    var token by remember { mutableStateOf(s.hfToken) }
    var sys by remember { mutableStateOf(s.systemPrompt) }
    var lan by remember { mutableStateOf(s.serverLan) }

    Column(
        Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Hugging Face", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
            token, { token = it; s.hfToken = it }, label = { Text("アクセストークン(任意・gatedモデル用)") },
            singleLine = true, visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Text("推論(モデルの再読込で反映)", style = MaterialTheme.typography.titleMedium)
        NumField("コンテキスト長", s.nCtx.toString()) { it.toIntOrNull()?.let { v -> s.nCtx = v } }
        NumField("スレッド数(目安: 4)", s.threads.toString()) { it.toIntOrNull()?.let { v -> s.threads = v } }

        Text("生成", style = MaterialTheme.typography.titleMedium)
        NumField("最大トークン数", s.maxTokens.toString()) { it.toIntOrNull()?.let { v -> s.maxTokens = v } }
        NumField("温度(0で決定的)", s.temperature.toString(), KeyboardType.Decimal) {
            it.toFloatOrNull()?.let { v -> s.temperature = v }
        }
        OutlinedTextField(
            sys, { sys = it; s.systemPrompt = it }, label = { Text("システムプロンプト") },
            modifier = Modifier.fillMaxWidth(), minLines = 2
        )

        Text("OpenAI互換APIサーバー", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("サーバーを起動", Modifier.weight(1f))
            Switch(checked = running, onCheckedChange = { serverErr = Core.setServer(it) })
        }
        NumField("ポート", s.serverPort.toString()) { it.toIntOrNull()?.let { v -> s.serverPort = v } }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("LANに公開(認証なし・信頼できるネットワークのみ)", Modifier.weight(1f))
            Switch(checked = lan, onCheckedChange = { lan = it; s.serverLan = it })
        }
        Text(
            "エンドポイント: http://${if (lan) "<端末のIP>" else "127.0.0.1"}:${s.serverPort}/v1/chat/completions\n" +
                "ポート・公開範囲の変更はサーバーの再起動で反映されます。",
            style = MaterialTheme.typography.bodySmall
        )
        serverErr?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}
