package com.example.localllm

import android.content.Context

class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var hfToken: String
        get() = p.getString("hf_token", "") ?: ""
        set(v) { p.edit().putString("hf_token", v.trim()).apply() }
    var nCtx: Int
        get() = p.getInt("n_ctx", 2048)
        set(v) { p.edit().putInt("n_ctx", v.coerceIn(256, 32768)).apply() }
    var threads: Int
        get() = p.getInt("threads", 4)
        set(v) { p.edit().putInt("threads", v.coerceIn(1, 16)).apply() }
    var maxTokens: Int
        get() = p.getInt("max_tokens", 512)
        set(v) { p.edit().putInt("max_tokens", v.coerceIn(16, 8192)).apply() }
    var temperature: Float
        get() = p.getFloat("temp", 0.7f)
        set(v) { p.edit().putFloat("temp", v.coerceIn(0f, 2f)).apply() }
    var systemPrompt: String
        get() = p.getString("system", "あなたは親切なアシスタントです。") ?: ""
        set(v) { p.edit().putString("system", v).apply() }
    var serverPort: Int
        get() = p.getInt("port", 8080)
        set(v) { p.edit().putInt("port", v.coerceIn(1024, 65535)).apply() }
    var serverLan: Boolean
        get() = p.getBoolean("lan", false)
        set(v) { p.edit().putBoolean("lan", v).apply() }
}
