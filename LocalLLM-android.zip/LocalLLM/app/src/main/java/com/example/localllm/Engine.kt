package com.example.localllm

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

data class ChatMsg(val role: String, val text: String)

object Engine {
    val loaded = MutableStateFlow<String?>(null)
    private var handle = 0L
    private val mutex = Mutex()

    suspend fun load(file: File) = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (handle != 0L) { LlamaBridge.free(handle); handle = 0; loaded.value = null }
            val h = LlamaBridge.load(file.absolutePath, Core.settings.nCtx, Core.settings.threads)
            if (h == 0L) error("モデルを読み込めませんでした(メモリ不足、または非対応の形式かもしれません)")
            handle = h
            loaded.value = file.name
        }
    }

    suspend fun unload() = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (handle != 0L) { LlamaBridge.free(handle); handle = 0; loaded.value = null }
        }
    }

    fun stop() = LlamaBridge.stop()

    suspend fun chat(
        messages: List<ChatMsg>, maxTokens: Int, temp: Float, onToken: (String) -> Boolean,
    ) {
        // 長くなりすぎた履歴は古い方から落とす(おおよその文字数で判定)
        val limit = Core.settings.nCtx * 3 / 2
        val list = messages.toMutableList()
        while (list.sumOf { it.text.length } > limit) {
            val i = list.indexOfFirst { it.role != "system" }
            if (i < 0 || i >= list.lastIndex) break
            list.removeAt(i)
            if (list.getOrNull(i)?.role == "assistant" && i < list.lastIndex) list.removeAt(i)
        }
        withContext(Dispatchers.IO) {
            mutex.withLock {
                check(handle != 0L) { "モデルが読み込まれていません" }
                LlamaBridge.generate(
                    handle,
                    list.map { it.role }.toTypedArray(),
                    list.map { it.text.toByteArray(Charsets.UTF_8) }.toTypedArray(),
                    maxTokens, temp,
                    TokenCallback { bytes ->
                        try { onToken(String(bytes, Charsets.UTF_8)) } catch (e: Exception) { false }
                    }
                )
            }
        }
    }
}
