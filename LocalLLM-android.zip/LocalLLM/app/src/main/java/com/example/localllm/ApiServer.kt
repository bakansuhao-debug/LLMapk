package com.example.localllm

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.serialization.json.*
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

/** OpenAI互換の簡易HTTPサーバー(/v1/models, /v1/chat/completions) */
class ApiServer {
    val running = MutableStateFlow(false)
    private var sock: ServerSocket? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val json = Json { ignoreUnknownKeys = true }

    fun start(port: Int, lan: Boolean) {
        if (running.value) return
        val s = ServerSocket()
        s.reuseAddress = true
        s.bind(InetSocketAddress(if (lan) "0.0.0.0" else "127.0.0.1", port))
        sock = s
        running.value = true
        scope.launch {
            while (!s.isClosed) {
                val c = try { s.accept() } catch (e: Exception) { break }
                launch {
                    try { handle(c) } catch (_: Exception) {} finally { runCatching { c.close() } }
                }
            }
            running.value = false
            Core.refreshBusy()
        }
    }

    fun stop() {
        runCatching { sock?.close() }
        sock = null
        running.value = false
    }

    private fun readLine(inp: BufferedInputStream): String? {
        val sb = ByteArrayOutputStream()
        while (true) {
            val b = inp.read()
            if (b < 0) return if (sb.size() == 0) null else sb.toString("UTF-8")
            if (b == '\n'.code) break
            if (b != '\r'.code) sb.write(b)
        }
        return sb.toString("UTF-8")
    }

    private suspend fun handle(c: Socket) {
        val inp = BufferedInputStream(c.getInputStream())
        val out = BufferedOutputStream(c.getOutputStream())
        val parts = (readLine(inp) ?: return).split(" ")
        if (parts.size < 2) return
        val method = parts[0]
        val path = parts[1].substringBefore('?')
        var len = 0
        while (true) {
            val l = readLine(inp) ?: break
            if (l.isEmpty()) break
            if (l.startsWith("content-length:", true)) len = l.substringAfter(':').trim().toIntOrNull() ?: 0
        }
        val body = ByteArray(len.coerceIn(0, 8_000_000))
        var off = 0
        while (off < body.size) {
            val n = inp.read(body, off, body.size - off)
            if (n < 0) break
            off += n
        }
        when {
            method == "OPTIONS" -> respond(out, 204, "")
            method == "GET" && path == "/" -> respond(out, 200, """{"status":"ok"}""")
            method == "GET" && path == "/v1/models" -> {
                val m = Engine.loaded.value
                val r = buildJsonObject {
                    put("object", "list")
                    putJsonArray("data") {
                        if (m != null) addJsonObject { put("id", m); put("object", "model") }
                    }
                }
                respond(out, 200, r.toString())
            }
            method == "POST" && path == "/v1/chat/completions" -> chat(out, String(body, Charsets.UTF_8))
            else -> respond(out, 404, err("not found"))
        }
    }

    private fun err(m: String) = buildJsonObject {
        putJsonObject("error") { put("message", m) }
    }.toString()

    private fun respond(out: OutputStream, code: Int, body: String) {
        val b = body.toByteArray(Charsets.UTF_8)
        out.write(
            ("HTTP/1.1 $code X\r\nContent-Type: application/json; charset=utf-8\r\n" +
                "Content-Length: ${b.size}\r\nConnection: close\r\n" + cors() + "\r\n").toByteArray()
        )
        out.write(b)
        out.flush()
    }

    private fun cors() =
        "Access-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: *\r\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\r\n"

    private fun contentText(e: JsonElement?): String = when (e) {
        is JsonPrimitive -> e.contentOrNull ?: ""
        is JsonArray -> e.joinToString("") { (it as? JsonObject)?.get("text")?.jsonPrimitive?.contentOrNull ?: "" }
        else -> ""
    }

    private fun chunk(content: String?, finish: String?) = buildJsonObject {
        put("id", "chatcmpl-local")
        put("object", "chat.completion.chunk")
        put("model", Engine.loaded.value ?: "")
        putJsonArray("choices") {
            addJsonObject {
                put("index", 0)
                putJsonObject("delta") { if (content != null) put("content", content) }
                put("finish_reason", finish)
            }
        }
    }.toString()

    private suspend fun chat(out: OutputStream, body: String) {
        if (Engine.loaded.value == null) { respond(out, 503, err("モデルが読み込まれていません")); return }
        val root = try { json.parseToJsonElement(body).jsonObject } catch (e: Exception) {
            respond(out, 400, err("invalid json")); return
        }
        val arr = root["messages"] as? JsonArray ?: run { respond(out, 400, err("messages required")); return }
        val msgs = arr.map {
            val o = it.jsonObject
            ChatMsg(o["role"]?.jsonPrimitive?.contentOrNull ?: "user", contentText(o["content"]))
        }
        val stream = root["stream"]?.jsonPrimitive?.booleanOrNull == true
        val maxTok = root["max_tokens"]?.jsonPrimitive?.intOrNull ?: Core.settings.maxTokens
        val temp = root["temperature"]?.jsonPrimitive?.floatOrNull ?: Core.settings.temperature

        if (stream) {
            out.write(
                ("HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nCache-Control: no-cache\r\n" +
                    "Connection: close\r\n" + cors() + "\r\n").toByteArray()
            )
            out.flush()
            Engine.chat(msgs, maxTok, temp) { piece ->
                out.write("data: ${chunk(piece, null)}\n\n".toByteArray(Charsets.UTF_8))
                out.flush()
                true
            }
            out.write("data: ${chunk(null, "stop")}\n\ndata: [DONE]\n\n".toByteArray())
            out.flush()
        } else {
            val sb = StringBuilder()
            Engine.chat(msgs, maxTok, temp) { sb.append(it); true }
            val r = buildJsonObject {
                put("id", "chatcmpl-local")
                put("object", "chat.completion")
                put("model", Engine.loaded.value ?: "")
                putJsonArray("choices") {
                    addJsonObject {
                        put("index", 0)
                        putJsonObject("message") { put("role", "assistant"); put("content", sb.toString()) }
                        put("finish_reason", "stop")
                    }
                }
            }
            respond(out, 200, r.toString())
        }
    }
}
