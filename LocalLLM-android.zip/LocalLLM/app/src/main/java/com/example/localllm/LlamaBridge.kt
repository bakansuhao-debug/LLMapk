package com.example.localllm

fun interface TokenCallback {
    /** UTF-8バイト列で受け取る。falseを返すと生成を止める */
    fun onToken(bytes: ByteArray): Boolean
}

object LlamaBridge {
    init { System.loadLibrary("llama_jni") }

    external fun load(path: String, nCtx: Int, nThreads: Int): Long
    external fun free(handle: Long)
    external fun stop()
    external fun generate(
        handle: Long, roles: Array<String>, contents: Array<ByteArray>,
        maxTokens: Int, temp: Float, cb: TokenCallback
    )
}
