package com.example.localllm

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap

data class DlState(
    val key: String, val file: String,
    val done: Long, val total: Long, val error: String? = null,
)

/** HFからのダウンロード。.partファイル + Rangeヘッダーで再開可能 */
class Downloads(private val hf: HfClient, private val store: ModelStore) {
    val active = MutableStateFlow<Map<String, DlState>>(emptyMap())
    private val jobs = ConcurrentHashMap<String, Job>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun put(s: DlState) = active.update { it + (s.key to s) }

    fun start(repo: String, file: String, size: Long) {
        val key = "$repo/$file"
        if (jobs.containsKey(key)) return
        put(DlState(key, file.substringAfterLast('/'), 0, size))
        jobs[key] = scope.launch {
            try {
                run(key, repo, file, size)
                active.update { it - key }
                store.changed()
            } catch (e: CancellationException) {
                active.update { it - key }
            } catch (e: Exception) {
                val cur = active.value[key]
                put(DlState(key, file.substringAfterLast('/'), cur?.done ?: 0, size, e.message ?: "エラー"))
            } finally {
                jobs.remove(key)
                Core.refreshBusy()
            }
        }
        Core.refreshBusy()
    }

    fun cancel(key: String) { jobs[key]?.cancel() }

    private suspend fun run(key: String, repo: String, file: String, size: Long) {
        val dest = store.fileFor(repo, file)
        val part = File(dest.path + ".part")
        var offset = if (part.exists()) part.length() else 0L
        val rb = hf.request(hf.resolveUrl(repo, file))
        if (offset > 0) rb.header("Range", "bytes=$offset-")
        hf.http.newCall(rb.build()).execute().use { r ->
            if (r.code == 416) { part.renameTo(dest); return }
            if (!r.isSuccessful) {
                error(
                    if (r.code == 401 || r.code == 403) "認証が必要です(設定でHFトークンを入力し、モデルページでライセンスに同意してください)"
                    else "HTTP ${r.code}"
                )
            }
            val append = r.code == 206
            if (!append) offset = 0
            val body = r.body!!
            val total = if (body.contentLength() > 0) body.contentLength() + offset else size
            var done = offset
            var last = 0L
            FileOutputStream(part, append).use { out ->
                body.byteStream().use { src ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = src.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - last > 300) {
                            last = now
                            put(DlState(key, file.substringAfterLast('/'), done, total))
                        }
                    }
                }
            }
        }
        if (!part.renameTo(dest)) error("ファイルの移動に失敗しました")
    }
}
