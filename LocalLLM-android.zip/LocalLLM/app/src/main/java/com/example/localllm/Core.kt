package com.example.localllm

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow

object Core {
    lateinit var app: Application
    lateinit var settings: Settings
    val hf by lazy { HfClient { settings.hfToken } }
    val store by lazy { ModelStore(app) }
    val downloads by lazy { Downloads(hf, store) }
    val server by lazy { ApiServer() }
    val busy = MutableStateFlow(false)

    fun init(a: Application) {
        app = a
        settings = Settings(a)
    }

    /** ダウンロード中・サーバー稼働中はフォアグラウンドサービスでプロセスを維持 */
    fun refreshBusy() {
        val b = downloads.active.value.values.any { it.error == null } || server.running.value
        busy.value = b
        if (b) ContextCompat.startForegroundService(app, Intent(app, AppService::class.java))
    }

    /** 成功ならnull、失敗ならエラーメッセージ */
    fun setServer(on: Boolean): String? = try {
        if (on) server.start(settings.serverPort, settings.serverLan) else server.stop()
        refreshBusy()
        null
    } catch (e: Exception) {
        e.message ?: "サーバーを起動できませんでした"
    }
}
