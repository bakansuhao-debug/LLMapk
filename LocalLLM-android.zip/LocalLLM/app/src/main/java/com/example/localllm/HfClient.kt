package com.example.localllm

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

@Serializable
data class HfModel(
    val id: String,
    val downloads: Long = 0,
    val likes: Int = 0,
    val gated: JsonElement? = null,
)

@Serializable
data class HfSibling(val rfilename: String, val size: Long? = null)

@Serializable
data class HfModelDetail(val id: String, val siblings: List<HfSibling> = emptyList())

class HfClient(private val token: () -> String) {
    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    fun request(url: String): Request.Builder {
        val b = Request.Builder().url(url).header("User-Agent", "LocalLLM-Android/0.1")
        token().takeIf { it.isNotBlank() }?.let { b.header("Authorization", "Bearer $it") }
        return b
    }

    fun resolveUrl(repo: String, file: String) = "https://huggingface.co/$repo/resolve/main/$file"

    suspend fun search(q: String): List<HfModel> = withContext(Dispatchers.IO) {
        val url = "https://huggingface.co/api/models".toHttpUrl().newBuilder()
            .addQueryParameter("search", q)
            .addQueryParameter("filter", "gguf")
            .addQueryParameter("sort", "downloads")
            .addQueryParameter("direction", "-1")
            .addQueryParameter("limit", "30")
            .build()
        http.newCall(request(url.toString()).build()).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code}")
            json.decodeFromString<List<HfModel>>(r.body!!.string())
        }
    }

    /** リポジトリ内のGGUFファイル一覧(サイズ付き)。分割GGUFとmmprojは除外 */
    suspend fun files(repo: String): List<HfSibling> = withContext(Dispatchers.IO) {
        val url = "https://huggingface.co/api/models/$repo?blobs=true"
        http.newCall(request(url).build()).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code}")
            json.decodeFromString<HfModelDetail>(r.body!!.string()).siblings
                .filter {
                    it.rfilename.endsWith(".gguf", true) &&
                        !it.rfilename.contains("mmproj", true) &&
                        !Regex("-\\d{5}-of-\\d{5}").containsMatchIn(it.rfilename)
                }
                .sortedBy { it.size ?: Long.MAX_VALUE }
        }
    }
}
