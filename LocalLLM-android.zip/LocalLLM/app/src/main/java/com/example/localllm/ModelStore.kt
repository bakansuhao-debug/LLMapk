package com.example.localllm

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

class ModelStore(ctx: Context) {
    val dir = File(ctx.filesDir, "models").apply { mkdirs() }
    val version = MutableStateFlow(0)

    fun fileFor(repo: String, file: String) =
        File(dir, repo.replace('/', '_') + "__" + file.substringAfterLast('/'))

    fun list(): List<File> =
        dir.listFiles { f -> f.extension == "gguf" }?.sortedBy { it.name } ?: emptyList()

    fun delete(f: File) { f.delete(); version.value++ }
    fun changed() { version.value++ }
}
